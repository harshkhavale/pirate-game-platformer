
## Project    : Sudoku-Life
## Contributor: Shad-Alam 

<br/>

:writing_hand: **Description:** <br/>

- Sudoku is very popular game. In this project, I was trying to generate sudoku puzzle with five different levels. <br/>

## Project presentation: https://youtu.be/SUhO2Exu4DU

<br/> 

![ezcv logo](https://github.com/Shad-Alam/Sudoku-Life/blob/main/Main/screenshot/01.png)

<br/>

![ezcv logo](https://github.com/Shad-Alam/Sudoku-Life/blob/main/Main/screenshot/02.png)

* Released: January 15, 2023
